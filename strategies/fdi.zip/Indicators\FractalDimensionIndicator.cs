#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class FractalDimensionIndicator : Indicator
	{
		private Series<double> smooth;
		private Series<double> price;
		private Series<double> ratio;
		private double n1, n2, n3, hh, ll = 0;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"This is the Fractal Dimension Indicator as described in the May 2010 issue of Stocks & Commodities.";
				Name										= "FractalDimensionIndicator";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				N											= 30;
				AddPlot(Brushes.Red, "Dimension_Plot");
				AddLine(Brushes.DodgerBlue, 1, "FuzzyUpper");
				AddLine(Brushes.DodgerBlue, 1, "FuzzyLower");
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{				
				smooth = new Series<double>(this);
				price = new Series<double>(this);
				ratio = new Series<double>(this);
			}
		}

		protected override void OnBarUpdate()
		{
			  price[0] = (High[0] + Low[0]) / 2;
			
			if (CurrentBar == 0)
				smooth[0] = price[0];
			else if (CurrentBar == 1)
				smooth[0] = (price[0] + 2 * price[1]) / 3;
			else if (CurrentBar == 2)
				smooth[0] = (price[0] + 2 * price[1] + 2 * price[2]) / 5;
			else
				smooth[0] = (price[0] + 2 * price[1] + 2 * price[2] + price[3]) / 6;
			
			if (CurrentBar < N)
				return;			
			
			n3 = (MAX(smooth, N)[0] - MIN(smooth, N)[0]) / N;
			hh = smooth[0];
			ll = smooth[0];
			
			for (int index = 0; index <= (N / 2 - 1); index++) 
			{
				if (smooth[index] > hh)
					hh = smooth[index];
				if (smooth[index] < ll)
					ll = smooth[index];
			}
						
			n1 = (hh - ll) / (N / 2);
			hh = smooth[N / 2];
			ll = smooth[N / 2];
			
			for (int index = (N / 2); index <= (N - 1); index++)
			{
				if (smooth[index] > hh)
					hh = smooth[index];
				if (smooth[index] < ll)
					ll = smooth[index];
			}
						
			n2 = (hh - ll) / (N / 2);
			
			if (n1 > 0 && n2 > 0 && n3 > 0)
				ratio[0] = 0.5 * ((Math.Log10(n1 + n2) - Math.Log10(n3)) / Math.Log10(2) + Dimension_Plot[1]);
			
            Dimension_Plot[0] = SMA(ratio, 20)[0];
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(2, int.MaxValue)]
		[Display(Name="N", Description="Number of bars to average. Must be an even number.", Order=1, GroupName="Parameters")]
		public int N
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Dimension_Plot
		{
			get { return Values[0]; }
		}


		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private FractalDimensionIndicator[] cacheFractalDimensionIndicator;
		public FractalDimensionIndicator FractalDimensionIndicator(int n)
		{
			return FractalDimensionIndicator(Input, n);
		}

		public FractalDimensionIndicator FractalDimensionIndicator(ISeries<double> input, int n)
		{
			if (cacheFractalDimensionIndicator != null)
				for (int idx = 0; idx < cacheFractalDimensionIndicator.Length; idx++)
					if (cacheFractalDimensionIndicator[idx] != null && cacheFractalDimensionIndicator[idx].N == n && cacheFractalDimensionIndicator[idx].EqualsInput(input))
						return cacheFractalDimensionIndicator[idx];
			return CacheIndicator<FractalDimensionIndicator>(new FractalDimensionIndicator(){ N = n }, input, ref cacheFractalDimensionIndicator);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.FractalDimensionIndicator FractalDimensionIndicator(int n)
		{
			return indicator.FractalDimensionIndicator(Input, n);
		}

		public Indicators.FractalDimensionIndicator FractalDimensionIndicator(ISeries<double> input , int n)
		{
			return indicator.FractalDimensionIndicator(input, n);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.FractalDimensionIndicator FractalDimensionIndicator(int n)
		{
			return indicator.FractalDimensionIndicator(Input, n);
		}

		public Indicators.FractalDimensionIndicator FractalDimensionIndicator(ISeries<double> input , int n)
		{
			return indicator.FractalDimensionIndicator(input, n);
		}
	}
}

#endregion
